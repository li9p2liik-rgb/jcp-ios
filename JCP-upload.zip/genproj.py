#!/usr/bin/env python3
"""Generate JCP.xcodeproj - no external dependencies."""
import hashlib, os, sys
from pathlib import Path

# Use script-relative path to avoid encoding issues
SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parent.parent  # scripts/ -> repo root

PROJ_DIR = ROOT / "JCP.xcodeproj"
PROJ_DIR.mkdir(exist_ok=True)

def hid(s, length=24):
    return hashlib.sha256(s.encode()).hexdigest().upper()[:length]

# ===== Collect files =====
def rel(p):
    return p.relative_to(ROOT).as_posix()

swift_files = sorted([rel(p) for p in (ROOT / "JCP").rglob("*.swift")])
plist_files = sorted([rel(p) for p in (ROOT / "JCP").rglob("*.plist")])
test_files = sorted([rel(p) for p in (ROOT / "JCPTests").rglob("*.swift")])
all_source_files = swift_files + plist_files

print(f"Swift sources: {len(swift_files)}")
print(f"Plist files:   {len(plist_files)}")
print(f"Test files:    {len(test_files)}")

# ===== Generate IDs =====
ID = {}
for key in ["pbx", "mainGrp", "srcGrp", "testGrp", "prod", "testProd",
            "srcBp", "testBp", "resBp", "fwBp",
            "target", "testTarget",
            "cfgList", "testCfgList", "projCfgList",
            "dbg", "rel", "tdbg", "trel", "pdbg", "prel"]:
    ID[key] = hid(key)

file_id = {}
build_id = {}
for f in swift_files + plist_files:
    file_id[f] = hid("F" + f)
for f in swift_files:
    build_id[f] = hid("B" + f)
for f in test_files:
    file_id[f] = hid("TF" + f)
    build_id[f] = hid("TB" + f)

# ===== PBXBuildFile =====
bld = []
for f in swift_files:
    bld.append(f'\t\t{build_id[f]} /* {Path(f).name} in Sources */ = {{isa = PBXBuildFile; fileRef = {file_id[f]} /* {Path(f).name} */; }};')
for f in test_files:
    bld.append(f'\t\t{build_id[f]} /* {Path(f).name} in Sources */ = {{isa = PBXBuildFile; fileRef = {file_id[f]} /* {Path(f).name} */; }};')

# ===== PBXFileReference =====
frf = []
for f in swift_files:
    frf.append(f'\t\t{file_id[f]} /* {Path(f).name} */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "{Path(f).name}"; sourceTree = "<group>"; }};')
for f in plist_files:
    frf.append(f'\t\t{file_id[f]} /* {Path(f).name} */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = "{Path(f).name}"; sourceTree = "<group>"; }};')
for f in test_files:
    frf.append(f'\t\t{file_id[f]} /* {Path(f).name} */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "{Path(f).name}"; sourceTree = "<group>"; }};')
frf.append(f'\t\t{ID["prod"]} /* JCP.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = JCP.app; sourceTree = BUILT_PRODUCTS_DIR; }};')
frf.append(f'\t\t{ID["testProd"]} /* JCPTests.xctest */ = {{isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = JCPTests.xctest; sourceTree = BUILT_PRODUCTS_DIR; }};')

# ===== PBXGroup (recursive tree builder) =====
def group_tree(base, files, prefix=""):
    """Build nested dict from file paths."""
    tree = {}
    for f in files:
        parts = Path(f).relative_to(base).parts
        d = tree
        for p in parts[:-1]:
            d = d.setdefault(p, {})
        d.setdefault("__f__", []).append(f)
    return tree

def render_tree(tree, depth=3):
    lines = []
    indent = "\t" * depth
    for k, v in sorted(tree.items()):
        if k == "__f__":
            for f in sorted(v):
                lines.append(f"{indent}{file_id[f]} /* {Path(f).name} */,")
        else:
            gid = hid("G" + k)
            lines.append(f"{indent}{gid} /* {k} */ = {{isa = PBXGroup; children = (")
            lines.extend(render_tree(v, depth + 1))
            lines.append(f"{indent}}}); path = {k}; sourceTree = \"<group>\";")
    return lines

src_tree = group_tree("JCP", swift_files + plist_files)
test_tree = group_tree("JCPTests", test_files)

# Source group root
src_top = []
for k in sorted(src_tree.keys()):
    if k != "__f__":
        src_top.append(f'\t\t\t{hid("G"+k)} /* {k} */,')
# Resources separate
res_gid = hid("GResources")
src_top.append(f'\t\t\t{res_gid} /* Resources */,')

# Test group
test_top = []
for k in sorted(test_tree.keys()):
    if k != "__f__":
        test_top.append(f'\t\t\t{hid("G"+k)} /* {k} */,')
# Direct files in test root
for f in test_files:
    if "/" not in Path(f).relative_to("JCPTests").as_posix():
        test_top.append(f'\t\t\t{file_id[f]} /* {Path(f).name} */,')

# Resources group children
res_children = []
for f in plist_files:
    res_children.append(f'\t\t\t{file_id[f]} /* {Path(f).name} */,')

# Build group section
groups = []

# Main group
groups.append(f'\t\t{ID["mainGrp"]} = {{isa = PBXGroup; children = (\n\t\t\t{ID["srcGrp"]} /* JCP */,\n\t\t\t{ID["testGrp"]} /* JCPTests */,\n\t\t\t{ID["prod"]} /* JCP.app */,\n\t\t\t{ID["testProd"]} /* JCPTests.xctest */,\n\t\t); sourceTree = "<group>"; }};')

# Source group
groups.append(f'\t\t{ID["srcGrp"]} /* JCP */ = {{isa = PBXGroup; children = (\n' + "\n".join(src_top) + f'\n\t\t); path = JCP; sourceTree = "<group>"; }};')

# Test group
groups.append(f'\t\t{ID["testGrp"]} /* JCPTests */ = {{isa = PBXGroup; children = (\n' + "\n".join(test_top) + f'\n\t\t); path = JCPTests; sourceTree = "<group>"; }};')

# Resources group
groups.append(f'\t\t{res_gid} /* Resources */ = {{isa = PBXGroup; children = (\n' + "\n".join(res_children) + f'\n\t\t); path = Resources; sourceTree = "<group>"; }};')

# Sub-groups
groups.extend(render_tree(src_tree))

# ===== Build phases =====
src_phase = "\n".join([f'\t\t\t\t{build_id[f]} /* {Path(f).name} in Sources */,' for f in swift_files])
test_phase = "\n".join([f'\t\t\t\t{build_id[f]} /* {Path(f).name} in Sources */,' for f in test_files])

# ===== Config macros =====
def cfg(id, name, settings):
    s = " ".join(f'{k} = {v};' for k, v in settings.items())
    return f'\t\t{id} /* {name} */ = {{isa = XCBuildConfiguration; buildSettings = {{{s}}}; name = {name}; }};'

APP_SETTINGS = {
    'ASSETCATALOG_COMPILER_APPICON_NAME': '""',
    'CODE_SIGN_STYLE': 'Automatic',
    'CURRENT_PROJECT_VERSION': '1',
    'INFOPLIST_FILE': 'JCP/Resources/Info.plist',
    'IPHONEOS_DEPLOYMENT_TARGET': '17.0',
    'MARKETING_VERSION': '1.0',
    'PRODUCT_BUNDLE_IDENTIFIER': 'com.jcp.app',
    'PRODUCT_NAME': '"$(TARGET_NAME)"',
    'SWIFT_VERSION': '5.0',
    'TARGETED_DEVICE_FAMILY': '"1,2"',
}

TEST_SETTINGS = {
    'BUNDLE_LOADER': '"$(TEST_HOST)"',
    'CODE_SIGN_STYLE': 'Automatic',
    'CURRENT_PROJECT_VERSION': '1',
    'IPHONEOS_DEPLOYMENT_TARGET': '17.0',
    'MARKETING_VERSION': '1.0',
    'PRODUCT_BUNDLE_IDENTIFIER': 'com.jcp.appTests',
    'PRODUCT_NAME': '"$(TARGET_NAME)"',
    'SWIFT_VERSION': '5.0',
    'TARGETED_DEVICE_FAMILY': '"1,2"',
    'TEST_HOST': '"$(BUILT_PRODUCTS_DIR)/JCP.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/JCP"',
}

PROJ_DBG = {
    'ALWAYS_SEARCH_USER_PATHS': 'NO',
    'CLANG_CXX_LANGUAGE_STANDARD': '"gnu++20"',
    'CLANG_ENABLE_MODULES': 'YES',
    'CLANG_ENABLE_OBJC_ARC': 'YES',
    'DEBUG_INFORMATION_FORMAT': 'dwarf',
    'ENABLE_TESTABILITY': 'YES',
    'GCC_OPTIMIZATION_LEVEL': '0',
    'IPHONEOS_DEPLOYMENT_TARGET': '17.0',
    'MTL_ENABLE_DEBUG_INFO': 'INCLUDE_SOURCE',
    'ONLY_ACTIVE_ARCH': 'YES',
    'SDKROOT': 'iphoneos',
    'SWIFT_ACTIVE_COMPILATION_CONDITIONS': 'DEBUG',
    'SWIFT_OPTIMIZATION_LEVEL': '"-Onone"',
}

PROJ_REL = {
    'ALWAYS_SEARCH_USER_PATHS': 'NO',
    'CLANG_CXX_LANGUAGE_STANDARD': '"gnu++20"',
    'CLANG_ENABLE_MODULES': 'YES',
    'CLANG_ENABLE_OBJC_ARC': 'YES',
    'DEBUG_INFORMATION_FORMAT': '"dwarf-with-dsym"',
    'GCC_OPTIMIZATION_LEVEL': 's',
    'IPHONEOS_DEPLOYMENT_TARGET': '17.0',
    'MTL_ENABLE_DEBUG_INFO': 'NO',
    'SDKROOT': 'iphoneos',
    'SWIFT_COMPILATION_MODE': 'wholemodule',
    'SWIFT_OPTIMIZATION_LEVEL': '"-O"',
    'VALIDATE_PRODUCT': 'YES',
}

# ===== Assemble =====
pbxproj = f"""// !$*UTF8*$!
{{
\tarchiveVersion = 1;
\tclasses = {{}};
\tobjectVersion = 60;
\tobjects = {{

/* Begin PBXBuildFile section */
{chr(10).join(bld)}
/* End PBXBuildFile section */

/* Begin PBXFileReference section */
{chr(10).join(frf)}
/* End PBXFileReference section */

/* Begin PBXFrameworksBuildPhase section */
\t\t{ID["fwBp"]} /* Frameworks */ = {{isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0; }};
/* End PBXFrameworksBuildPhase section */

/* Begin PBXGroup section */
{chr(10).join(groups)}
/* End PBXGroup section */

/* Begin PBXNativeTarget section */
\t\t{ID["target"]} /* JCP */ = {{
\t\t\tisa = PBXNativeTarget;
\t\t\tbuildConfigurationList = {ID["cfgList"]};
\t\t\tbuildPhases = ({ID["srcBp"]} /* Sources */, {ID["fwBp"]} /* Frameworks */, {ID["resBp"]} /* Resources */,);
\t\t\tbuildRules = ();
\t\t\tdependencies = ();
\t\t\tname = JCP;
\t\t\tproductName = JCP;
\t\t\tproductReference = {ID["prod"]};
\t\t\tproductType = "com.apple.product-type.application";
\t\t}};
\t\t{ID["testTarget"]} /* JCPTests */ = {{
\t\t\tisa = PBXNativeTarget;
\t\t\tbuildConfigurationList = {ID["testCfgList"]};
\t\t\tbuildPhases = ({ID["testBp"]} /* Sources */,);
\t\t\tbuildRules = ();
\t\t\tdependencies = ();
\t\t\tname = JCPTests;
\t\t\tproductName = JCPTests;
\t\t\tproductReference = {ID["testProd"]};
\t\t\tproductType = "com.apple.product-type.bundle.unit-test";
\t\t}};
/* End PBXNativeTarget section */

/* Begin PBXProject section */
\t\t{ID["pbx"]} /* Project object */ = {{
\t\t\tisa = PBXProject;
\t\t\tattributes = {{ BuildIndependentTargetsInParallel = 1; LastSwiftUpdateCheck = 1630; LastUpgradeCheck = 1630; }};
\t\t\tbuildConfigurationList = {ID["projCfgList"]};
\t\t\tcompatibilityVersion = "Xcode 14.0";
\t\t\tdevelopmentRegion = "zh-Hans";
\t\t\thasScannedForEncodings = 0;
\t\t\tknownRegions = (en, Base, "zh-Hans",);
\t\t\tmainGroup = {ID["mainGrp"]};
\t\t\tproductRefGroup = {ID["mainGrp"]};
\t\t\tprojectDirPath = "";
\t\t\tprojectRoot = "";
\t\t\ttargets = ({ID["target"]} /* JCP */, {ID["testTarget"]} /* JCPTests */,);
\t\t}};
/* End PBXProject section */

/* Begin PBXResourcesBuildPhase section */
\t\t{ID["resBp"]} /* Resources */ = {{isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0; }};
/* End PBXResourcesBuildPhase section */

/* Begin PBXSourcesBuildPhase section */
\t\t{ID["srcBp"]} /* Sources */ = {{isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (
{src_phase}
\t\t); runOnlyForDeploymentPostprocessing = 0; }};
\t\t{ID["testBp"]} /* Sources */ = {{isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (
{test_phase}
\t\t); runOnlyForDeploymentPostprocessing = 0; }};
/* End PBXSourcesBuildPhase section */

/* Begin XCBuildConfiguration section */
{cfg(ID["dbg"], "Debug", APP_SETTINGS)}
{cfg(ID["rel"], "Release", APP_SETTINGS)}
{cfg(ID["tdbg"], "Debug", TEST_SETTINGS)}
{cfg(ID["trel"], "Release", TEST_SETTINGS)}
{cfg(ID["pdbg"], "Debug", PROJ_DBG)}
{cfg(ID["prel"], "Release", PROJ_REL)}
/* End XCBuildConfiguration section */

/* Begin XCConfigurationList section */
\t\t{ID["cfgList"]} /* Build configuration list for PBXNativeTarget "JCP" */ = {{isa = XCConfigurationList; buildConfigurations = ({ID["dbg"]} /* Debug */, {ID["rel"]} /* Release */,); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; }};
\t\t{ID["testCfgList"]} /* Build configuration list for PBXNativeTarget "JCPTests" */ = {{isa = XCConfigurationList; buildConfigurations = ({ID["tdbg"]} /* Debug */, {ID["trel"]} /* Release */,); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; }};
\t\t{ID["projCfgList"]} /* Build configuration list for PBXProject "JCP" */ = {{isa = XCConfigurationList; buildConfigurations = ({ID["pdbg"]} /* Debug */, {ID["prel"]} /* Release */,); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; }};
/* End XCConfigurationList section */
\t}};
\trootObject = {ID["pbx"]} /* Project object */;
}}
"""

out = PROJ_DIR / "project.pbxproj"
out.write_text(pbxproj, encoding="utf-8")
print(f"\nGenerated: {out}")
print(f"Size: {len(pbxproj)} bytes")
print("OK — project ready for Xcode")
